#!/bin/bash

#edxpgtool Builder - :#

#Makes a Live cd that is installable from your current installation
#This is intended to work on Ubuntu and its derivatives
#
#Based on this tutorial: 
#https://help.ubuntu.com/community/MakeALiveCD/DVD/BootableFlashFromHarddiskInstall
#and Distroshare Ubuntu Imager - https://github.com/Distroshare/distroshare-ubuntu-imager

#GPL2 License

VERSION="1.0"

echo "
################################################
######                                    ######
######                                    ######
######  edxpgtool Builder $VERSION            ######
######                                    ######
######                                    ######
######       Brought to you by edxpgtool      ######
######                                    ######
######                                    ######
################################################


"

#Configuration file name and path
CONFIG_FILE="./edxpgtool.config"

#Current directory
CURRENT_DIR=`pwd`

#Convience function to unmount filesystems
unmount_filesystems() {
    echo "Unmounting filesystems"
    umount "${WORK}"/rootfs/proc > /dev/null 2>&1
    umount "${WORK}"/rootfs/sys > /dev/null 2>&1
    umount -l "${WORK}"/rootfs/dev/pts > /dev/null 2>&1
    umount -l "${WORK}"/rootfs/dev > /dev/null 2>&1
}

#Starting the process

#We depend on the umask being 022
umask 022

#Source the config file
if [ -r "$CONFIG_FILE" ]; then
    . "$CONFIG_FILE"
else
    echo "Can't read config file.  Exiting"
    exit 1
fi

#Set some other variables based on the config file
CD="${WORK}"/CD
CASPER="${CD}"/casper

#Checking for root
if [ "$USER" != "root" ]; then
    echo "You aren't root, so I'm exiting.  Become root and try again."
    exit 1
fi

#Make the directories
echo "Making the necessary directories"
mkdir -p "${CD}"/casper
mkdir -p "${CD}"/boot/grub
mkdir -p "${WORK}"/rootfs

#Install essential tools
echo "Installing the essential tools"
apt-get -q=2 update
apt-get -q=2 install xorriso squashfs-tools dmraid lvm2 samba-common

GRUB2_INSTALLED=`apt-cache policy grub-pc | grep Installed | grep -v none`
#EFI support requires a different grub version. 
if [ "$EFI" == "YES" ]
then
    ARCH=`/usr/bin/arch`
    if [ "$ARCH" == "x86_64" ]
    then 
	apt-get -q=2 install grub-efi-amd64
    else
	apt-get -q=2 install grub-efi-ia32
    fi
else
    apt-get -q=2 install grub-pc
fi


echo "Installing Ubiquity"
apt-get -q=2 install casper lupin-casper
if [ "$GTK" == "YES" ]; then
   apt-get -q=2 install ubiquity-frontend-gtk
else
   apt-get -q=2 install ubiquity-frontend-kde
fi

if [ -n "$EXTRA_PKGS" ]; then
   echo "Adding extra packages to installed system"
   apt-get -q=2 install "$EXTRA_PKGS"
fi

echo "Patching Ubiquity to fix a possible installer crash"
cp /usr/share/ubiquity/plugininstall.py .
patch < plugininstall.patch
cp plugininstall.py /usr/share/ubiquity/plugininstall.py
rm -f plugininstall.py

echo "Patching Ubiquity to stop it from freaking out if zram is enabled"
cp /usr/bin/ubiquity .
patch < ubiquity.patch
cp ubiquity /usr/bin/
rm -f ubiquity

if [ "$GTK" == "YES" ]
then
    echo "Patching Ubiquity Gtk Frontend to make the dialogs smaller"
    cp /usr/lib/ubiquity/ubiquity/frontend/gtk_ui.py .
    patch < ubiquity_frontend_gtk_dialog_size.patch
    cp gtk_ui.py /usr/lib/ubiquity/ubiquity/frontend/gtk_ui.py
    rm -f gtk_ui.py
fi

if [ "$BROS_UPDATER" == "YES" ]
then
   echo "Patching Ubiquity to rsync skel files from edxpgtool updater"
   cp /usr/lib/ubiquity/user-setup/user-setup-apply .
   patch < user-setup-apply.patch
   cp user-setup-apply /usr/lib/ubiquity/user-setup/user-setup-apply
   rm -f user-setup-apply

   echo "Patching user-setup to rsync skel files from edxpgtool updater"
   cp /usr/lib/user-setup/user-setup-apply .
   patch < user-setup-apply.patch
   cp user-setup-apply /usr/lib/user-setup/user-setup-apply
   rm -f user-setup-apply
fi

#Copy the filesystem
echo "Copying the current system to the new directories"
rsync -a --one-file-system --exclude=/proc/* --exclude=/dev/* \
--exclude=/sys/* --exclude=/tmp/* --exclude=/run/* \
--exclude=/home/* --exclude=/lost+found \
--exclude=/var/tmp/* --exclude=/boot --exclude=/root/* \
--exclude=/var/mail/* --exclude=/var/spool/* --exclude=/media/* \
--exclude=/etc/hosts --exclude=/etc/default/locale \
--exclude=/etc/timezone --exclude=/etc/shadow* --exclude=/etc/gshadow* \
--exclude=/etc/X11/xorg.conf* --exclude=/etc/gdm/custom.conf --exclude=/etc/mdm/mdm.conf \
--exclude=/etc/lightdm/lightdm.conf --exclude="${WORK}"/rootfs \
--exclude=/etc/default/du-firstrun --delete / "${WORK}"/rootfs

#Copy boot partition
echo "Copying the boot dir/partition"
rsync -a --one-file-system /boot/ "${WORK}"/rootfs/boot

#Unmount the filesystems in case the script failed before
unmount_filesystems

#Create devices in /dev
echo "Creating some links and dirs in /dev"
mkdir "${WORK}"/rootfs/dev/mapper > /dev/null 2>&1
mkdir "${WORK}"/rootfs/dev/pts > /dev/null 2>&1
ln -s /proc/kcore "${WORK}"/rootfs/dev/core > /dev/null 2>&1
ln -s /proc/self/fd "${WORK}"/rootfs/dev/fd > /dev/null 2>&1
cd "${WORK}"/rootfs/dev
ln -s fd/2 stderr > /dev/null 2>&1
ln -s fd/0 stdin > /dev/null 2>&1
ln -s fd/1 stdout > /dev/null 2>&1
ln -s ram1 ram > /dev/null 2>&1
ln -s shm /run/shm > /dev/null 2>&1

mknod agpgart c 10 175
chown root:video agpgart
chmod 660 agpgart

mknod audio c 14 4
mknod audio1 c 14 20
mknod audio2 c 14 36
mknod audio3 c 14 52
mknod audioctl c 14 7
chown root:audio audio*
chmod 660 audio*

mknod console c 5 1
chown root:tty console
chmod 600 console

mknod dsp c 14 3
mknod dsp1 c 14 19
mknod dsp2 c 14 35
mknod dsp3 c 14 51
chown root:audio dsp*
chmod 660 dsp*

mknod full c 1 7
chown root:root full
chmod 666 full

mknod fuse c 10 229
chown root:messagebus fuse
chmod 660 fuse

mknod kmem c 1 2
chown root:kmem kmem
chmod 640 kmem

mknod loop0 b 7 0
mknod loop1 b 7 1
mknod loop2 b 7 2
mknod loop3 b 7 3
mknod loop4 b 7 4
mknod loop5 b 7 5
mknod loop6 b 7 6
mknod loop7 b 7 7
chown root:disk loop*
chmod 660 loop*

cd mapper
mknod control c 10 236
chown root:root control
chmod 600 control
cd ..

mknod mem c 1 1
chown root:kmem mem
chmod 640 mem

mknod midi0 c 35 0
mknod midi00 c 14 2
mknod midi01 c 14 18
mknod midi02 c 14 34
mknod midi03 c 14 50
mknod midi1 c 35 1
mknod midi2 c 35 2
mknod midi3 c 35 3
chown root:audio midi*
chmod 660 midi*

mknod mixer c 14 0
mknod mixer1 c 14 16
mknod mixer2 c 14 32
mknod mixer3 c 14 48
chown root:audio mixer*
chmod 660 mixer*

mknod mpu401data c 31 0
mknod mpu401stat c 31 1
chown root:audio mpu401*
chmod 660 mpu401*

mknod null c 1 3
chown root:root null
chmod 666 null

mknod port c 1 4
chown root:kmem port
chmod 640 port

mknod ptmx c 5 2
chown root:tty ptmx
chmod 666 ptmx

mknod ram0 b 1 0
mknod ram1 b 1 1
mknod ram2 b 1 2
mknod ram3 b 1 3
mknod ram4 b 1 4
mknod ram5 b 1 5
mknod ram6 b 1 6
mknod ram7 b 1 7
mknod ram8 b 1 8
mknod ram9 b 1 9
mknod ram10 b 1 10
mknod ram11 b 1 11
mknod ram12 b 1 12
mknod ram13 b 1 13
mknod ram14 b 1 14
mknod ram15 b 1 15
mknod ram16 b 1 16
chown root:disk ram*
chmod 660 ram*

mknod random c 1 8
chown root:root random
chmod 666 random

mknod rmidi0 c 35 64
mknod rmidi1 c 35 65
mknod rmidi2 c 35 66
mknod rmidi3 c 35 67
chown root:audio rmidi*
chmod 660 rmidi*

mknod sequencer c 14 1
chown root:audio sequencer
chmod 660 sequencer

mknod smpte0 c 35 128
mknod smpte1 c 35 129
mknod smpte2 c 35 130
mknod smpte3 c 35 131
chown root:audio smpte*
chmod 660 smpte*

mknod sndstat c 14 6
chown root:audio sndstat
chmod 660 sndstat

mknod tty c 5 0
mknod tty0 c 4 0
mknod tty1 c 4 1
mknod tty2 c 4 2
mknod tty3 c 4 3
mknod tty4 c 4 4
mknod tty5 c 4 5
mknod tty6 c 4 6
mknod tty7 c 4 7
mknod tty8 c 4 8
mknod tty9 c 4 9
chown root:tty tty*
chmod 600 tty*

mknod urandom c 1 9
chown root:root urandom
chmod 666 urandom

mknod zero c 1 5
chown root:root zero
chmod 666 zero

cd "${CURRENT_DIR}"
#Copy the resolv.conf file - needed for newer Ubuntus
echo "Copying resolv.conf"
mv "${WORK}"/rootfs/etc/resolv.conf "${WORK}"/rootfs/etc/resolv.conf.old
cp /etc/resolv.conf "${WORK}"/rootfs/etc/resolv.conf

#Mount dirs into copied distro
echo "Mounting system file dirs"
mount --bind /dev/ "${WORK}"/rootfs/dev
mount --bind /dev/pts "${WORK}"/rootfs/dev/pts
mount -t proc proc "${WORK}"/rootfs/proc
mount -t sysfs sysfs "${WORK}"/rootfs/sys

#Remove non-system users
echo "Removing non-system users"
for i in `cat "${WORK}"/rootfs/etc/passwd | awk -F":" '{print $1}'`
do
   uid=`cat "${WORK}"/rootfs/etc/passwd | grep "^${i}:" | awk -F":" '{print $3}'`
   [ "$uid" -gt "998" -a  "$uid" -ne "65534"  ] && \
       chroot "${WORK}"/rootfs /bin/bash -c "userdel --force ${i} 2> /dev/null"
done

#Source lsb-release for DISTRIB_ID
. /etc/lsb-release

#Run commands in chroot
echo "Creating script to run in chrooted env"
cat > "${WORK}"/rootfs/edxpgtool_builder.sh <<EOF
#!/bin/bash

umask 022

#Modify copied distro
if [ -n "$UBIQUITY_KERNEL_PARAMS" ]; then
  echo "Replacing ubiquity default extra kernel params with: $UBIQUITY_KERNEL_PARAMS"
  sed -i "s/defopt_params=\"\"/defopt_params=\"${UBIQUITY_KERNEL_PARAMS}\"/" \
/usr/share/grub-installer/grub-installer
fi

#Set flavour in /etc/casper.conf
echo "export FLAVOUR=\"${DISTRIB_ID}\"" >> /etc/casper.conf

echo "Setting up display manager for autologin if needed"
#Testing for MDM and applying specific changes for it
if [ "${DM}" == "MDM" ]; then
    sed -i 's/gdm\/custom.conf/mdm\/mdm.conf/' \
/usr/share/initramfs-tools/scripts/casper-bottom/15autologin
    mkdir -p /etc/mdm
    echo "[daemon]
#AutomaticLoginEnable = false
#AutomaticLogin = none
#TimedLoginEnable = false
" > /etc/mdm/mdm.conf
    #Copy /etc/apt/sources.list to /etc/apt/sources.list.new
    cp /etc/apt/sources.list /etc/apt/sources.list.new
fi

#Testing for GDM and applying specific changes for it
if [ "${DM}" == "GDM" ]; then
    mkdir -p /etc/gdm
    echo "[daemon]
#AutomaticLoginEnable = false
#AutomaticLogin = none
#TimedLoginEnable = false
" > /etc/gdm/custom.conf
fi

if [ "${DM}" == "KDM" ]; then
    mkdir -p /etc/kde4/kdm
    echo "[X-:0-Core]
AutoLoginEnable=false
AutoLoginUser=none
AutoReLogin=false
" > /etc/kde4/kdm/kdmrc
fi

if [ "${DM}" == "LIGHTDM_UBUNTU_MATE" ]; then
 sed -i 's/\/etc\/lightdm\/lightdm.conf/\/usr\/share\/lightdm\/lightdm.conf.d\/60-lightdm-gtk-greeter.conf/' \
/usr/share/initramfs-tools/scripts/casper-bottom/15autologin

 sed -i 's/autologin-session=lightdm-autologin/user-session=mate/' \
/usr/share/initramfs-tools/scripts/casper-bottom/15autologin
fi

if [ "${DM}" == "LIGHTDM_ZORIN" ]; then
 echo "[SeatDefaults]
user-session=zorin_desktop
" > /etc/lightdm/lightdm.conf

 sed -i 's/autologin-session=lightdm-autologin/user-session=zorin_desktop/' \
/usr/share/initramfs-tools/scripts/casper-bottom/15autologin
fi

if [ "${DM}" == "LIGHTDM_KODIBUNTU" ]; then
 echo "[SeatDefaults]
xserver-command=/usr/bin/X -bs -nolisten tcp
user-session=kodi
allow-guest=false
greeter-session=lightdm-gtk-greeter
" > /etc/lightdm/lightdm.conf

 sed -i 's/autologin-session=lightdm-autologin/user-session=kodi/' \
/usr/share/initramfs-tools/scripts/casper-bottom/15autologin
fi

if [ "${DM}" == "LIGHTDM_DEEPIN" ]; then
 echo "[SeatDefaults]
greeter-session=lightdm-deepin-greeter
user-session=deepin
" > /etc/lightdm/lightdm.conf

 sed -i 's/autologin-session=lightdm-autologin/user-session=deepin/' \
/usr/share/initramfs-tools/scripts/casper-bottom/15autologin

 #Fix for installer icon on desktop 
 sed -i 's/ubiquity.desktop/ubiquity-gtkui.desktop/' \
/usr/share/initramfs-tools/scripts/casper-bottom/25adduser
fi

#Update initramfs 
echo "Updating initramfs"
depmod -a $(uname -r)
update-initramfs -u -k all > /dev/null 2>&1

#Clean up downloaded packages
echo "Cleaning up files that are not needed in the new image"
apt-get clean

#Clean up files
#rm -f /etc/X11/xorg.conf*
rm -f /etc/hosts
rm -f /etc/hostname
rm -f /etc/mtab*
rm -f /etc/fstab
rm -f /etc/udev/rules.d/70-persistent*
rm -f /etc/cups/ssl/server.crt
rm -f /etc/cups/ssl/server.key
rm -f /etc/NetworkManager/system-connections/*
rm -f /etc/ssh/*key*
rm -f /var/lib/dbus/machine-id
rm -f /etc/resolv.conf
mv /etc/resolv.conf.old /etc/resolv.conf
truncate -s 0 /etc/printcap > /dev/null 2>&1
truncate -s 0 /etc/cups/printers.conf
rm -rf /var/lib/sudo/*
rm -rf /var/lib/AccountsService/users/*
rm -rf /var/lib/kdm/*
rm -rf /var/lib/lightdm/*
rm -rf /var/lib/lightdm-data/*
rm -rf /var/lib/gdm/*
rm -rf /var/lib/gdm-data/*
rm -rf /var/lib/mdm/*
rm -rf /var/lib/mdm-data/*
rm -rf /var/run/console/*

#If /var/run is a link, then it is pointing to /run
if [ ! -L /var/run ]; then
  find /var/run/ -type f -exec rm -f {} \;
fi

#If /var/lock is a link, then it is pointing to /run/lock
if [ ! -L /var/lock ]; then
  find /var/lock/ -type f -exec rm -f {} \;
fi

#Clean up files - taken from BlackLab Imager
find /var/backups/ /var/spool/ /var/mail/ \
/var/tmp/ /var/crash/ \
/var/lib/ubiquity/ -type f -exec rm -f {} \;

#Remove archived logs
find /var/log -type f -name '*.[0-9]*' -exec rm -f {} \;

#Truncate all logs
find /var/log -type f -exec truncate -s 0 {} \;

EOF

echo "Running script in chrooted env"
chmod 700 "${WORK}"/rootfs/edxpgtool_builder.sh
chown root:root "${WORK}"/rootfs/edxpgtool_builder.sh
chroot "${WORK}"/rootfs /edxpgtool_builder.sh
rm -f "${WORK}"/rootfs/edxpgtool_builder.sh

echo "Copying over kernel and initrd"
cp -p "${WORK}"/rootfs/boot/vmlinuz-"${KERNEL_VERSION}" "${CASPER}"/vmlinuz
cp -p "${WORK}"/rootfs/boot/initrd.img-"${KERNEL_VERSION}" "${CASPER}"/initrd.img
cp -p "${WORK}"/rootfs/boot/memtest86+.bin "${CD}"/boot

echo "Creating filesystem.manifest"
dpkg-query -W --showformat='${Package} ${Version}\n' > "${CASPER}"/filesystem.manifest

cp "${CASPER}"/filesystem.manifest "${CASPER}"/filesystem.manifest-desktop
REMOVE='ubiquity ubiquity-frontend-gtk ubiquity-frontend-kde casper user-setup os-prober libdebian-installer4 apt-clone archdetect-deb dpkg-repack gir1.2-json-1.0 gir1.2-timezonemap-1.0 gir1.2-xkl-1.0 libdebian-installer4 libparted-fs-resize0 libtimezonemap-data libtimezonemap1 python3-icu python3-pam rdate sbsigntool ubiquity-casper ubiquity-ubuntu-artwork localechooser-data cifs-utils  gir1.2-appindicator3-0.1 gir1.2-javascriptcoregtk-3.0 gir1.2-vte-2.90 gir1.2-webkit-3.0' 
for i in $REMOVE
do
   sed -i "/${i}/d" "${CASPER}"/filesystem.manifest-desktop
done

#Remove the extra script created to prevent an error message
rm -f "$CASPER_EXTRA_SCRIPT"

echo "Uninstalling Ubiquity"
apt-get -q=2 remove casper lupin-casper ubiquity user-setup

if [ -n "$EXTRA_PKGS" ]; then
   echo "Removing extra packages from installed system"
   apt-get -q=2 remove "$EXTRA_PKGS"
fi

if [ -n "$GRUB2_INSTALLED" -a "$EFI" == "YES" ]
then
    sudo apt-get install grub-pc
fi

echo "Removing temp files"
rm -rf "${WORK}"/rootfs/tmp/*
rm -rf "${WORK}"/rootfs/run/*

unmount_filesystems
echo "Making squashfs - this is going to take a while"
mksquashfs "${WORK}"/rootfs "${CASPER}"/filesystem.squashfs -noappend

echo "Making filesystem.size"
echo -n $(du -s --block-size=1 "${WORK}"/rootfs | \
    tail -1 | awk '{print $1}') > "${CASPER}"/filesystem.size
echo "Making md5sum"
rm -f "${CD}"/md5sum.txt
find "${CD}" -type f -print0 | xargs -0 md5sum | sed "s@${CD}@.@" | \
    grep -v md5sum.txt >> "${CD}"/md5sum.txt

echo "Creating release notes url"
mkdir "${CD}"/.disk
echo "${RELEASE_NOTES_URL}" > "${CD}"/.disk/release_notes_url

echo "Creating grub.cfg"
echo "
set default=\"0\"
set timeout=10

menuentry \"BrOS GUI\" {
linux /casper/vmlinuz boot=casper $KERNEL_PARAMS quiet splash --
initrd /casper/initrd.img
}

menuentry \"BrOS in safe mode\" {
linux /casper/vmlinuz boot=casper $KERNEL_PARAMS xforcevesa quiet splash --
initrd /casper/initrd.img
}

menuentry \"Check Disk for Defects\" {
linux /casper/vmlinuz boot=casper $KERNEL_PARAMS integrity-check quiet splash --
initrd /casper/initrd.img
}

menuentry \"Memory Test\" {
linux16 /boot/memtest86+.bin --
}

menuentry \"Boot from the first hard disk\" {
set root=(hd0)
chainloader +1
}
" > "${CD}"/boot/grub/grub.cfg

echo "Creating the iso"
grub-mkrescue -o "${WORK}"/live-cd.iso "${CD}"

echo "We are done."


edxpgtool.config

#Should we install the ubiquity gtk frontend? 
#YES for gtk, anything else for QT
GTK="NO"

#The directory where everything will be copied to and set up.
WORK="/home/brosbuilder"

#Patch ubiquity to support distroshare updater. Most people would say NO here.
edxpgtool_UPDATER="NO"

#Display Manager
#Set to GDM, MDM, KDM, LIGHTDM, LIGTHDM_UBUNTU_MATE, LIGHTDM_ZORIN, or LIGHTDM_KODIBUNTU.
#LIGHTDM is used by most Ubuntu based distros. Specific modifications to the lightdm 
#configuration is needed for some distributions.
#DM="LIGHTDM"
#DM="MDM"
#DM="KDM"
#DM="GDM"
#DM="LIGHTDM_UBUNTU_MATE"
#DM="LIGHTDM_ZORIN"
#DM="LIGHTDM_KODIBUNTU"
#DM="LIGHTDM_DEEPIN"
#DM="LIGHTDM"
DM="SDDM"

#EFI Support
EFI="YES"

#A specific kernel version to use for the Live CD. This could be useful
#if you are using a custom kernel that does not have the aufs module built
#in.
#KERNEL_VERSION="3.13.0-24-generic"
KERNEL_VERSION=$(uname -r)

#The kernel boot parameters of the live cd. 
KERNEL_PARAMS=""

#The kernel boot parameters that ubiquity (the installer) will
#set in /etc/default/grub for the installation.  Often, this
#will be the same as KERNEL_PARAMS.
UBIQUITY_KERNEL_PARAMS=""

#Extra packages to install in the image.  Packages must be separated by a space.
EXTRA_PKGS="ubiquity-slideshow-lubuntu"

#Release notes url that shows up after the Ubiquity installer is started.
RELEASE_NOTES_URL=""


README.MD

edxpgtool Builder
=============

This project is brought to you by edxpgtool Builder.  edxpgtool Builder is 
a tool use by edxpgtool to build the iso imago of the distro.


edxpgtool Builder creates an installable Live ISO from an installed 
Ubuntu or derivative distribution.

It is a bash script, similar to Remastersys and its forks.  The script is 
based on this tutorial: https://help.ubuntu.com/community/MakeALiveCD/DVD/BootableFlashFromHarddiskInstall
and Distroshare Script: https://github.com/Distroshare/distroshare-ubuntu-imager 

To run the script, run it from the directory where it is located.  For example:


cd ~/edxpgtool-builder
./edxpgtool-builder.sh

To boot the ISO from a USB stick, you can use the dd command like this:

dd if=isoimage.iso of=/dev/sdb bs=1M

where sdb is your USB drive.  You should be able something similar on Mac OS X.
You can also use UNetbootin: http://unetbootin.sourceforge.net/ to create a 
bootable USB drive.

Ubuntu Startup Disk creator won't be able to turn the iso into a bootable 
usb drive since edxpgtool_Builder uses grub2 as the bootloader.
 



LICENSE


GNU GENERAL PUBLIC LICENSE
                       Version 2, June 1991

 Copyright (C) 1989, 1991 Free Software Foundation, Inc., <http://fsf.org/>
 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
 Everyone is permitted to copy and distribute verbatim copies
 of this license document, but changing it is not allowed.

                            Preamble

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation's software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Lesser General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author's protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone's free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.

                    GNU GENERAL PUBLIC LICENSE
   TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program's
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

                            NO WARRANTY

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

                     END OF TERMS AND CONDITIONS

            How to Apply These Terms to Your New Programs

  If you develop a new program, and you want it to be of the greatest
possible use to the public, the best way to achieve this is to make it
free software which everyone can redistribute and change under these terms.

  To do so, attach the following notices to the program.  It is safest
to attach them to the start of each source file to most effectively
convey the exclusion of warranty; and each file should have at least
the "copyright" line and a pointer to where the full notice is found.

    {description}
    Copyright (C) {year}  {fullname}

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

Also add information on how to contact you by electronic and paper mail.

If the program is interactive, make it output a short notice like this
when it starts in an interactive mode:

    Gnomovision version 69, Copyright (C) year name of author
    Gnomovision comes with ABSOLUTELY NO WARRANTY; for details type `show w'.
    This is free software, and you are welcome to redistribute it
    under certain conditions; type `show c' for details.

The hypothetical commands `show w' and `show c' should show the appropriate
parts of the General Public License.  Of course, the commands you use may
be called something other than `show w' and `show c'; they could even be
mouse-clicks or menu items--whatever suits your program.

You should also get your employer (if you work as a programmer) or your
school, if any, to sign a "copyright disclaimer" for the program, if
necessary.  Here is a sample; alter the names:

  Yoyodyne, Inc., hereby disclaims all copyright interest in the program
  `Gnomovision' (which makes passes at compilers) written by James Hacker.

  {signature of Ty Coon}, 1 April 1989
  Ty Coon, President of Vice

This General Public License does not permit incorporating your program into
proprietary programs.  If your program is a subroutine library, you may
consider it more useful to permit linking proprietary applications with the
library.  If this is what you want to do, use the GNU Lesser General
Public License instead of this License.




plugininstall.patch







--- plugininstall.py	2014-12-12 14:45:35.907519660 -0700
+++ plugininstall.py	2014-12-12 14:46:06.231519117 -0700
@@ -1690,7 +1690,7 @@
                 status_gz.write(data)
             status_gz.close()
             status.close()
-        except IOError:
+        except:
             pass
         try:
             if self.db.get('oem-config/enable') == 'true':






ubiquity.patch





--- ubiquity	2015-01-02 13:26:26.748251749 -0500
+++ ubiquity	2015-01-02 13:27:52.291000221 -0500
@@ -11,7 +11,7 @@
 sys.path.insert(0, '/usr/lib/ubiquity')
 
 from ubiquity import osextras
-
+from subprocess import call
 
 def main():
     newargv = []
@@ -34,6 +34,10 @@
 
     if os.getuid() == 0:
         # no privilege escalation required
+
+        #Turn off all swaps to fix issues with zram
+        call(["swapoff", "--all"])	
+        
         inner = ['/usr/lib/ubiquity/bin/ubiquity'] + newargv
 
         # Make sure ibus works






ubiquity-frontend-gtk-dialog-size.patch


--- gtk_ui.py	2015-04-21 11:06:44.000000000 -0600
+++ gtk_ui.py	2015-06-10 12:21:50.716649795 -0600
@@ -42,6 +42,7 @@
 import sys
 import syslog
 import traceback
+import textwrap
 
 import dbus
 from dbus.mainloop.glib import DBusGMainLoop
@@ -371,6 +372,10 @@
             self.live_installer.connect(
                 'key-press-event', self.a11y_profile_keys)
 
+    #Re-format error messages so each line is at most 100 characters long
+    def fix_msg_line_len(self, msg):
+        return '\n'.join(textwrap.wrap(msg, 100))
+ 
     def all_children(self, parent):
         if isinstance(parent, Gtk.Container):
             def recurse(x, y):
@@ -818,6 +823,7 @@
             else:
                 txt = self.finished_label.get_label()
                 txt = txt.replace('${RELEASE}', misc.get_release().name)
+            txt = self.fix_msg_line_len(txt)
             self.finished_label.set_label(txt)
             with misc.raised_privileges():
                 with open('/var/run/reboot-required', "w"):
@@ -1723,6 +1729,7 @@
         self.set_busy_cursor(False)
         if not msg:
             msg = title
+        msg = self.fix_msg_line_len(msg)
         dialog = Gtk.MessageDialog(
             self.live_installer, Gtk.DialogFlags.MODAL,
             Gtk.MessageType.ERROR, Gtk.ButtonsType.OK, msg)
@@ -1771,6 +1778,7 @@
         self.set_busy_cursor(False)
         if not msg:
             msg = title
+        msg = self.fix_msg_line_len(msg)
         buttons = []
         for option in options:
             if use_templates:







user-setup-apply.patch




--- user-setup-apply	2012-10-15 03:31:33.000000000 -0600
+++ user-setup-apply	2015-05-06 21:43:02.854506004 -0600
@@ -398,4 +398,15 @@
 	db_set passwd/user-password-again ''
 fi
 
+DISTRO=`cat /etc/lsb-release | grep DISTRIB_ID | cut -f 2 -d "=" | sed -e 's/"//g'`
+DISTRO_VERSION=`cat /etc/lsb-release | grep DISTRIB_RELEASE | cut -f 2 -d "=" | sed -e 's/"//g'`
+DISTRO_NAME="${DISTRO}_${DISTRO_VERSION}"
+MACHINE=`$ROOT/usr/sbin/dmidecode | grep Product | cut -f 2 -d ":" | sed -e 's/[^a-zA-Z0-9_]*//g'`
+MACHINE_DIR="/var/lib/bros-builder/updates/${MACHINE}_${DISTRO_NAME}/"
+if [ -d "${ROOT}/${MACHINE_DIR}/etc/skel" ]
+  then
+  $chroot $ROOT /usr/bin/rsync -a "${MACHINE_DIR}/etc/skel/" /home/$USER/
+  $chroot $ROOT chown -R "$USER:$USER" "/home/$USER" >/dev/null || true
+fi
+
 exit 0



